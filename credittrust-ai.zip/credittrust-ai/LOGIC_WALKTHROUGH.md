# Demo script: showing the logic to faculty

A suggested order, each with the file to have open, what to point at, and
exact wording you can use. Total: ~8-10 minutes.

---

## 1. Start the app (30 sec)

```bash
cd backend
uvicorn app.main:app --reload
```

**Say:** "This is one Python process — FastAPI — serving both the trained
models and the website. There's no separate frontend server."

Open `http://localhost:8000` in the browser, and `http://localhost:8000/docs`
in a second tab (FastAPI's auto-generated API explorer — good to keep open,
it proves the endpoints are real, not mocked).

---

## 2. Data & preprocessing — `backend/app/ml/data.py` and `preprocess.py`

**Show:** `data.py`, function `load_dataset()`.

**Say:** "Our dataset has 10 applicant features — credit utilization, age,
debt ratio, late-payment counts, and so on — matching the 'Give Me Some
Credit' schema from the report. Before any model sees this data, it goes
through `preprocess.py`: missing income and dependents are median-imputed,
extreme values are capped at the 99.5th percentile, and invalid ages are
dropped."

**Point at:** the `apply_preprocessing()` function, and explain the key
design choice — **it's the same function** called during training
(`train.py`) and during a live prediction (`inference.py`). "That's
deliberate: it's impossible for the live website to preprocess an applicant
differently than the model was trained on, because there's only one
function that does it."

---

## 3. Ensemble training — `backend/app/ml/train.py`

**Show:** `train.py`, the block that trains the 5 models (search for
`Training 5 candidate models`).

**Say:** "We train five algorithms on the identical held-out test split —
Logistic Regression and SVM on scaled features, Decision Tree, Random
Forest and XGBoost on raw features, matching the preprocessing choices in
the report. Each one is scored on accuracy, precision, recall, F1 and
ROC-AUC."

**Point at:** `best_name = max(metrics, key=lambda k: metrics[k]["roc_auc"])`

**Say:** "This line is the automatic promotion step — whichever model has
the highest ROC-AUC becomes the model the website actually serves. It isn't
hardcoded to XGBoost; if you retrain on different data and Random Forest
wins instead, the website switches to Random Forest automatically."

Switch to the browser, **Overview tab** — show the live leaderboard table
and the ROC-AUC bar chart, and point out the "Best" tag lines up with what
`train.py` printed in the terminal.

---

## 4. Dual explainability — `backend/app/ml/explain.py`

**Show:** `explain.py`, both functions: `compute_global_shap()` and
`explain_instance()`.

**Say:** "We use two explainability tools for two different jobs. SHAP
looks at a sample of the training data and tells us which features matter
*on average, across every applicant* — that's a global view. LIME does the
opposite: for *one specific applicant*, it perturbs their inputs slightly
and watches how the model's prediction moves, to tell us which of their
specific numbers pushed the decision up or down."

Switch to the browser, **Explainability tab** — this is the SHAP output,
computed once at training time and served from `models/shap_global.json`.

---

## 5. Live prediction — `backend/app/inference.py` + `app/main.py`

**Show:** `inference.py`, the `predict()` method, top to bottom.

**Say:** "This is the whole request path in one place: take the applicant's
raw inputs, run them through the exact same `apply_preprocessing()` we saw
in step 2, get a probability from the promoted model, then call LIME to
explain that one prediction, and finally write everything to the database."

Switch to the browser, **Try a Prediction tab**. Click **Load High Risk
Sample**, then **Predict Approval & Risk**.

**Say, while it loads:** "That request just hit `POST /api/predict` in
`main.py`, which calls `inference.predict()` — the function we just looked
at — and the response you're about to see, including the plain-language
explanation, is generated live, not pre-written."

Point out the risk badge, the probability, the ranked factors, and the
explanation paragraph. Then load the **Low Risk Sample** and predict again
to show the decision flips and the factors change accordingly.

---

## 6. The database — `backend/app/database.py`

**Say:** "Every prediction the API serves gets logged here" — open a
terminal and run:

```bash
sqlite3 backend/credittrust.db "SELECT id, applicant_name, model_name, default_probability, risk_label FROM predictions ORDER BY id DESC LIMIT 5;"
```

(Or just refresh `http://localhost:8000/docs`, expand `GET
/api/predictions/recent`, and click "Try it out" → "Execute".)

**Say:** "This is the audit trail — for a real lending decision, you need a
record of exactly what the model was shown and what it decided, and this
table is that record. It's plain SQLite on purpose — no ORM, no hidden
magic — so it's easy to inspect and explain."

---

## 7. Close (30 sec)

**Say:** "So end to end: real data goes through one shared preprocessing
function, five real models are trained and compared, the best one is
promoted automatically, every prediction is explained two ways — globally
with SHAP, locally with LIME — and every decision is written to a database
for audit. That's the full pipeline from the Review-2 report, actually
running."

---

## Anticipated questions

- **"Is this the real Kaggle dataset?"** — Be upfront: by default it's a
  synthetic dataset generated with the exact same 10 columns, similar scale
  (150,000 rows), and a similar ~7% default rate, because this environment
  didn't have internet access to download the real file. `README.md`
  explains how to drop in the real `cs-training.csv` — once it's there,
  `train.py` uses it automatically with no code changes. If you've already
  downloaded the real dataset for the report, use that copy here too.
- **"Why did Logistic Regression score so close to XGBoost?"** — because
  the underlying risk pattern in this data is mostly additive; XGBoost's
  advantage shows up on the non-linear interactions (e.g. high utilization
  *combined with* recent severe delinquency), which is exactly the kind of
  pattern a linear model structurally can't represent.
- **"What happens if I retrain?"** — `train.py` is deterministic (fixed
  random seeds) so metrics will match run to run on the same data; retrain
  after swapping in real data and the leaderboard, promoted model, and SHAP
  ranking all update automatically.
